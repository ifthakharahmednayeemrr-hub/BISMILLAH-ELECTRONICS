
import React, { useState, useMemo, useEffect } from 'react';
import { 
  Plus, 
  Search, 
  Edit2, 
  Trash2, 
  Filter,
  ChevronRight,
  AlertCircle,
  CheckCircle2,
  Loader2
} from 'lucide-react';
import { DB } from '../services/db';
import { Product } from '../types';
import { CATEGORIES } from '../constants';

const Inventory: React.FC = () => {
  const [products, setProducts] = useState<Product[]>([]);
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedCategory, setSelectedCategory] = useState('All');
  const [statusMsg, setStatusMsg] = useState<{type: 'success' | 'error', text: string} | null>(null);
  const [isSaving, setIsSaving] = useState(false);
  const [isLoading, setIsLoading] = useState(true);
  
  // Modal state
  const [editingId, setEditingId] = useState<string | null>(null);
  const [formData, setFormData] = useState<Partial<Product>>({
    name: '',
    code: '',
    category: CATEGORIES[0],
    purchasePrice: 0,
    sellingPrice: 0,
    stock: 0,
    supplier: ''
  });

  const loadProducts = async () => {
    setIsLoading(true);
    try {
      const data = await DB.getProducts();
      setProducts(data);
    } catch (err) {
      console.error(err);
    } finally {
      setIsLoading(false);
    }
  };

  useEffect(() => {
    loadProducts();
  }, []);

  const filteredProducts = useMemo(() => {
    return products.filter(p => {
      const matchesSearch = p.name.toLowerCase().includes(searchTerm.toLowerCase()) || 
                           p.code.toLowerCase().includes(searchTerm.toLowerCase());
      const matchesCategory = selectedCategory === 'All' || p.category === selectedCategory;
      return matchesSearch && matchesCategory;
    });
  }, [products, searchTerm, selectedCategory]);

  const handleOpenModal = (product?: Product) => {
    setStatusMsg(null);
    if (product) {
      setEditingId(product.id);
      setFormData({ ...product });
    } else {
      setEditingId(null);
      setFormData({
        name: '',
        code: `PRD-${Math.random().toString(36).substr(2, 6).toUpperCase()}`,
        category: CATEGORIES[0],
        purchasePrice: 0,
        sellingPrice: 0,
        stock: 0,
        supplier: ''
      });
    }
    setIsModalOpen(true);
  };

  const handleSave = async () => {
    setIsSaving(true);
    setStatusMsg(null);

    if (!formData.name?.trim() || !formData.code?.trim()) {
      setStatusMsg({ type: 'error', text: 'Name and Code are required.' });
      setIsSaving(false);
      return;
    }

    try {
      const productPayload: Product = {
        id: editingId || Math.random().toString(36).substr(2, 9),
        name: formData.name.trim(),
        code: formData.code.trim().toUpperCase(),
        category: formData.category || CATEGORIES[0],
        purchasePrice: Number(formData.purchasePrice) || 0,
        sellingPrice: Number(formData.sellingPrice) || 0,
        stock: Number(formData.stock) || 0,
        supplier: formData.supplier?.trim() || '',
        dateAdded: editingId 
          ? (products.find(p => p.id === editingId)?.dateAdded || new Date().toISOString()) 
          : new Date().toISOString()
      };

      await DB.saveProduct(productPayload);
      await loadProducts();
      
      setStatusMsg({ type: 'success', text: 'Cloud storage updated successfully.' });
      setTimeout(() => setIsModalOpen(false), 800);
    } catch (err) {
      console.error(err);
      setStatusMsg({ type: 'error', text: 'Failed to sync with Supabase.' });
    } finally {
      setIsSaving(false);
    }
  };

  const handleDelete = async (id: string) => {
    if (window.confirm('Purge this record from cloud storage permanently?')) {
      try {
        await DB.deleteProduct(id);
        await loadProducts();
      } catch (err) {
        console.error(err);
        alert('Deletion failed.');
      }
    }
  };

  return (
    <div className="space-y-6 animate-in slide-in-from-bottom-4 duration-500">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h2 className="text-2xl font-bold font-orbitron tracking-tight text-white uppercase flex items-center gap-2">
            Cloud Inventory
            <div className="w-2 h-2 rounded-full bg-green-500 animate-pulse" />
          </h2>
          <p className="text-slate-400 text-sm">Managing records in Supabase remote cluster.</p>
        </div>
        <button 
          onClick={() => handleOpenModal()}
          className="flex items-center justify-center gap-2 bg-blue-600 hover:bg-blue-500 text-white px-6 py-2.5 rounded-xl font-bold transition-all shadow-lg shadow-blue-600/20 active:scale-95"
        >
          <Plus className="w-5 h-5" />
          Add To Cloud
        </button>
      </div>

      <div className="bg-slate-900 border border-slate-800 rounded-2xl p-4 sm:p-6 shadow-xl relative min-h-[400px]">
        {isLoading && (
          <div className="absolute inset-0 bg-slate-900/50 backdrop-blur-sm z-10 flex items-center justify-center rounded-2xl">
            <Loader2 className="w-10 h-10 text-blue-500 animate-spin" />
          </div>
        )}
        
        <div className="flex flex-col md:flex-row gap-4 mb-6">
          <div className="flex-1 relative">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-slate-500" />
            <input 
              type="text"
              placeholder="Search remote database..."
              className="w-full bg-slate-950 border border-slate-800 rounded-xl pl-10 pr-4 py-2.5 text-sm focus:outline-none focus:border-blue-500 transition-colors text-slate-200"
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
            />
          </div>
          <div className="flex items-center gap-2">
            <Filter className="w-5 h-5 text-slate-500" />
            <select 
              className="bg-slate-950 border border-slate-800 rounded-xl px-4 py-2.5 text-sm focus:outline-none focus:border-blue-500 text-slate-300"
              value={selectedCategory}
              onChange={(e) => setSelectedCategory(e.target.value)}
            >
              <option value="All">All Categories</option>
              {CATEGORIES.map(c => <option key={c} value={c}>{c}</option>)}
            </select>
          </div>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-left">
            <thead>
              <tr className="text-slate-500 text-[10px] font-bold uppercase tracking-[0.2em] border-b border-slate-800">
                <th className="pb-4 px-4">Serial</th>
                <th className="pb-4 px-4">Item Name</th>
                <th className="pb-4 px-4">Category</th>
                <th className="pb-4 px-4">Buy (৳)</th>
                <th className="pb-4 px-4">Sell (৳)</th>
                <th className="pb-4 px-4 text-center">Stock</th>
                <th className="pb-4 px-4 text-right">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-800/50">
              {filteredProducts.map((p) => (
                <tr key={p.id} className="group hover:bg-slate-800/20 transition-colors">
                  <td className="py-4 px-4 font-mono text-xs text-blue-500/80">{p.code}</td>
                  <td className="py-4 px-4">
                    <p className="font-semibold text-sm text-slate-200">{p.name}</p>
                    <p className="text-[10px] text-slate-500 uppercase">{p.supplier || 'N/A'}</p>
                  </td>
                  <td className="py-4 px-4">
                    <span className="bg-slate-950 px-2 py-0.5 rounded text-[10px] text-slate-400 border border-slate-800 uppercase">
                      {p.category}
                    </span>
                  </td>
                  <td className="py-4 px-4 text-sm text-slate-500">৳{p.purchasePrice.toLocaleString()}</td>
                  <td className="py-4 px-4 text-sm text-blue-400 font-medium">৳{p.sellingPrice.toLocaleString()}</td>
                  <td className="py-4 px-4 text-center">
                    <div className="inline-flex items-center gap-2 bg-slate-950/50 px-3 py-1 rounded-full border border-slate-800">
                      <div className={`w-1.5 h-1.5 rounded-full ${p.stock < 10 ? 'bg-red-500 animate-pulse' : 'bg-green-500'}`} />
                      <span className={`text-xs font-bold ${p.stock < 10 ? 'text-red-400' : 'text-slate-400'}`}>
                        {p.stock}
                      </span>
                    </div>
                  </td>
                  <td className="py-4 px-4">
                    <div className="flex items-center justify-end gap-2 opacity-0 group-hover:opacity-100 transition-opacity">
                      <button onClick={() => handleOpenModal(p)} className="p-1.5 text-slate-500 hover:text-blue-400 transition-colors">
                        <Edit2 className="w-4 h-4" />
                      </button>
                      <button onClick={() => handleDelete(p.id)} className="p-1.5 text-slate-500 hover:text-red-400 transition-colors">
                        <Trash2 className="w-4 h-4" />
                      </button>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {isModalOpen && (
        <div className="fixed inset-0 z-[60] flex items-center justify-center p-4 bg-slate-950/80 backdrop-blur-md">
          <div className="bg-slate-900 border border-slate-800 rounded-3xl w-full max-w-xl shadow-2xl overflow-hidden">
            <div className="p-6 border-b border-slate-800 flex items-center justify-between">
              <h3 className="text-lg font-bold font-orbitron text-white uppercase">{editingId ? 'Update Record' : 'Register New Item'}</h3>
              <button onClick={() => setIsModalOpen(false)} className="p-2 text-slate-500 hover:text-white rounded-full">
                <ChevronRight className="w-6 h-6" />
              </button>
            </div>
            
            <div className="p-8 space-y-6">
              {statusMsg && (
                <div className={`p-4 rounded-xl flex items-center gap-3 border ${statusMsg.type === 'error' ? 'bg-red-500/10 border-red-500/20 text-red-400' : 'bg-green-500/10 border-green-500/20 text-green-400'}`}>
                  {statusMsg.type === 'error' ? <AlertCircle className="w-5 h-5" /> : <CheckCircle2 className="w-5 h-5" />}
                  <span className="text-xs font-bold uppercase">{statusMsg.text}</span>
                </div>
              )}

              <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
                <div className="space-y-1.5">
                  <label className="text-[10px] text-slate-500 font-bold uppercase">Item Name</label>
                  <input className="w-full bg-slate-950 border border-slate-800 rounded-xl px-4 py-3 text-sm focus:border-blue-500" value={formData.name} onChange={e => setFormData({...formData, name: e.target.value})} />
                </div>
                <div className="space-y-1.5">
                  <label className="text-[10px] text-slate-500 font-bold uppercase">Serial Code</label>
                  <input className="w-full bg-slate-950 border border-slate-800 rounded-xl px-4 py-3 text-sm font-mono uppercase text-blue-500" value={formData.code} onChange={e => setFormData({...formData, code: e.target.value})} />
                </div>
                <div className="space-y-1.5">
                  <label className="text-[10px] text-slate-500 font-bold uppercase">Sector</label>
                  <select className="w-full bg-slate-950 border border-slate-800 rounded-xl px-4 py-3 text-sm" value={formData.category} onChange={e => setFormData({...formData, category: e.target.value})}>
                    {CATEGORIES.map(c => <option key={c} value={c}>{c}</option>)}
                  </select>
                </div>
                <div className="space-y-1.5">
                  <label className="text-[10px] text-slate-500 font-bold uppercase">Stock Count</label>
                  <input type="number" className="w-full bg-slate-950 border border-slate-800 rounded-xl px-4 py-3 text-sm" value={formData.stock} onChange={e => setFormData({...formData, stock: Number(e.target.value)})} />
                </div>
                <div className="space-y-1.5">
                  <label className="text-[10px] text-slate-500 font-bold uppercase">Buy Price</label>
                  <input type="number" className="w-full bg-slate-950 border border-slate-800 rounded-xl px-4 py-3 text-sm" value={formData.purchasePrice} onChange={e => setFormData({...formData, purchasePrice: Number(e.target.value)})} />
                </div>
                <div className="space-y-1.5">
                  <label className="text-[10px] text-slate-500 font-bold uppercase">Sell Price</label>
                  <input type="number" className="w-full bg-slate-950 border border-slate-800 rounded-xl px-4 py-3 text-sm text-green-400 font-bold" value={formData.sellingPrice} onChange={e => setFormData({...formData, sellingPrice: Number(e.target.value)})} />
                </div>
              </div>
            </div>

            <div className="p-6 bg-slate-950/50 border-t border-slate-800 flex justify-end gap-3">
              <button disabled={isSaving} onClick={() => setIsModalOpen(false)} className="px-6 py-2.5 text-xs font-bold uppercase text-slate-500">Cancel</button>
              <button disabled={isSaving} onClick={handleSave} className="bg-blue-600 text-white px-10 py-2.5 rounded-xl font-bold flex items-center gap-2">
                {isSaving ? <Loader2 className="w-4 h-4 animate-spin" /> : (editingId ? 'Sync Update' : 'Push To Cloud')}
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default Inventory;
