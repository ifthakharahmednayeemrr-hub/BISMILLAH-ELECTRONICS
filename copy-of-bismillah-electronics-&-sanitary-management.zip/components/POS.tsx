
import React, { useState, useMemo, useEffect } from 'react';
import { 
  Barcode, 
  ShoppingCart, 
  Trash2, 
  Plus, 
  Minus,
  CheckCircle,
  AlertCircle,
  Loader2
} from 'lucide-react';
import { DB } from '../services/db';
import { Product, Sale } from '../types';

interface CartItem {
  product: Product;
  quantity: number;
}

const POS: React.FC = () => {
  const user = DB.getCurrentUser();
  const [products, setProducts] = useState<Product[]>([]);
  const [cart, setCart] = useState<CartItem[]>([]);
  const [inputCode, setInputCode] = useState('');
  const [error, setError] = useState<string | null>(null);
  const [success, setSuccess] = useState(false);
  const [isCheckingOut, setIsCheckingOut] = useState(false);
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    const loadProducts = async () => {
      try {
        const data = await DB.getProducts();
        setProducts(data);
      } catch (err) {
        console.error(err);
      } finally {
        setIsLoading(false);
      }
    };
    loadProducts();
  }, []);

  const total = useMemo(() => {
    return cart.reduce((acc, item) => acc + (item.product.sellingPrice * item.quantity), 0);
  }, [cart]);

  const addToCart = (e: React.FormEvent) => {
    e.preventDefault();
    const product = products.find(p => p.code === inputCode.trim().toUpperCase());
    
    if (!product) {
      setError('PRODUCT_NOT_IN_CLOUD_REGISTRY');
      return;
    }

    if (product.stock <= 0) {
      setError('ITEM_OUT_OF_STOCK');
      return;
    }

    const existing = cart.find(item => item.product.id === product.id);
    if (existing) {
      if (existing.quantity >= product.stock) {
        setError('MAX_REMOTE_STOCK_REACHED');
        return;
      }
      setCart(cart.map(item => item.product.id === product.id ? { ...item, quantity: item.quantity + 1 } : item));
    } else {
      setCart([...cart, { product, quantity: 1 }]);
    }
    
    setInputCode('');
    setError(null);
  };

  const updateQuantity = (productId: string, delta: number) => {
    setCart(cart.map(item => {
      if (item.product.id === productId) {
        const newQty = item.quantity + delta;
        if (newQty > 0 && newQty <= item.product.stock) {
          return { ...item, quantity: newQty };
        }
      }
      return item;
    }));
  };

  const removeItem = (productId: string) => {
    setCart(cart.filter(item => item.product.id !== productId));
  };

  const checkout = async () => {
    if (cart.length === 0) return;
    setIsCheckingOut(true);

    try {
      const salesPayload: Sale[] = cart.map(item => ({
        id: Math.random().toString(36).substr(2, 9),
        productCode: item.product.code,
        productName: item.product.name,
        quantity: item.quantity,
        unitPrice: item.product.sellingPrice,
        totalPrice: item.product.sellingPrice * item.quantity,
        profit: (item.product.sellingPrice - item.product.purchasePrice) * item.quantity,
        timestamp: new Date().toISOString(),
        soldBy: user?.name || 'Unknown'
      }));

      // 1. Add Sales Records
      await DB.addSales(salesPayload);

      // 2. Update Stock Levels in Supabase
      const updatePromises = cart.map(item => 
        DB.updateStock(item.product.id, item.product.stock - item.quantity)
      );
      await Promise.all(updatePromises);

      setCart([]);
      setSuccess(true);
      setTimeout(() => setSuccess(false), 3000);
      
      // Refresh local product cache
      const updatedProds = await DB.getProducts();
      setProducts(updatedProds);
    } catch (err) {
      console.error(err);
      setError('TRANSACTION_SYNC_FAILED');
    } finally {
      setIsCheckingOut(false);
    }
  };

  return (
    <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 h-full relative">
      {isLoading && (
        <div className="absolute inset-0 bg-slate-950/50 backdrop-blur-sm z-50 flex items-center justify-center">
          <Loader2 className="w-12 h-12 text-blue-500 animate-spin" />
        </div>
      )}

      <div className="lg:col-span-8 flex flex-col space-y-6">
        <div className="bg-slate-900 border border-slate-800 rounded-2xl p-6">
          <h2 className="text-xl font-bold font-orbitron mb-6 flex items-center gap-2">
            <Barcode className="w-5 h-5 text-blue-500" />
            VIRTUAL SCANNER
          </h2>
          <form onSubmit={addToCart} className="relative">
            <input 
              autoFocus
              className="w-full bg-slate-950 border-2 border-slate-800 rounded-2xl px-6 py-4 text-lg focus:border-blue-500 transition-all font-mono uppercase text-blue-400"
              placeholder="Enter Remote Code..."
              value={inputCode}
              onChange={(e) => setInputCode(e.target.value)}
            />
            <button type="submit" className="absolute right-3 top-1/2 -translate-y-1/2 bg-blue-600 hover:bg-blue-500 px-6 py-2 rounded-xl font-bold">Add</button>
          </form>
          {error && <p className="text-red-400 text-sm mt-3 flex items-center gap-1 uppercase font-bold tracking-tighter"><AlertCircle className="w-4 h-4" /> {error}</p>}
        </div>

        <div className="bg-slate-900 border border-slate-800 rounded-2xl flex-1 flex flex-col min-h-[400px]">
          <div className="p-6 border-b border-slate-800">
            <h3 className="font-bold uppercase tracking-wider text-slate-400 text-sm">Active Cart Session</h3>
          </div>
          <div className="flex-1 overflow-y-auto p-4 space-y-3">
            {cart.map((item) => (
              <div key={item.product.id} className="bg-slate-950 border border-slate-800 rounded-xl p-4 flex items-center justify-between group">
                <div className="flex-1">
                  <h4 className="font-bold text-slate-100">{item.product.name}</h4>
                  <div className="flex items-center gap-3 mt-1">
                    <span className="text-xs text-slate-500 font-mono">{item.product.code}</span>
                    <span className="text-xs text-green-500 font-bold">৳{item.product.sellingPrice}</span>
                  </div>
                </div>
                <div className="flex items-center gap-6">
                  <div className="flex items-center gap-2 bg-slate-900 rounded-lg p-1 border border-slate-800">
                    <button onClick={() => updateQuantity(item.product.id, -1)} className="p-1 hover:text-blue-400 transition-colors"><Minus className="w-4 h-4" /></button>
                    <span className="w-8 text-center font-bold">{item.quantity}</span>
                    <button onClick={() => updateQuantity(item.product.id, 1)} className="p-1 hover:text-blue-400 transition-colors"><Plus className="w-4 h-4" /></button>
                  </div>
                  <div className="w-24 text-right">
                    <span className="font-bold">৳{(item.product.sellingPrice * item.quantity).toLocaleString()}</span>
                  </div>
                  <button onClick={() => removeItem(item.product.id)} className="p-2 text-slate-600 hover:text-red-400 opacity-0 group-hover:opacity-100 transition-opacity">
                    <Trash2 className="w-4 h-4" />
                  </button>
                </div>
              </div>
            ))}
            {cart.length === 0 && !success && (
              <div className="h-full flex flex-col items-center justify-center text-slate-600 opacity-50 py-10">
                <ShoppingCart className="w-16 h-16 mb-4" />
                <p className="font-orbitron text-xs">AWAITING_CART_INPUT...</p>
              </div>
            )}
            {success && (
              <div className="h-full flex flex-col items-center justify-center text-green-400 py-10">
                <CheckCircle className="w-16 h-16 mb-4" />
                <p className="font-bold text-xl font-orbitron">CLOUD_SYNC_SUCCESS</p>
              </div>
            )}
          </div>
        </div>
      </div>

      <div className="lg:col-span-4">
        <div className="bg-slate-900 border border-slate-800 rounded-2xl overflow-hidden sticky top-24">
          <div className="p-6 bg-blue-600 text-white"><h3 className="font-orbitron font-bold uppercase">Transaction Summary</h3></div>
          <div className="p-6 space-y-4">
            <div className="flex justify-between text-slate-400 text-sm"><span>Remote Subtotal</span><span>৳{total.toLocaleString()}</span></div>
            <div className="flex justify-between text-slate-400 text-sm"><span>Tax/Vat</span><span>৳0</span></div>
            <div className="pt-4 border-t border-slate-800 flex justify-between items-end">
              <span className="text-slate-200 font-bold">NET TOTAL</span>
              <span className="text-3xl font-bold text-blue-400">৳{total.toLocaleString()}</span>
            </div>
            <button disabled={cart.length === 0 || isCheckingOut} onClick={checkout} className={`w-full py-4 rounded-xl font-bold text-lg mt-6 flex items-center justify-center gap-2 ${cart.length > 0 ? 'bg-blue-600 text-white' : 'bg-slate-800 text-slate-500'}`}>
              {isCheckingOut ? <Loader2 className="w-6 h-6 animate-spin" /> : 'COMMIT TRANSACTION'}
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};

export default POS;
