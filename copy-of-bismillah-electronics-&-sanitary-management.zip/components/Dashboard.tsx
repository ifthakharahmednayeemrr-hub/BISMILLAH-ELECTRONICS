
import React, { useMemo, useEffect, useState } from 'react';
import { 
  BarChart, 
  Bar, 
  XAxis, 
  YAxis, 
  CartesianGrid, 
  Tooltip, 
  ResponsiveContainer, 
  AreaChart, 
  Area 
} from 'recharts';
import { 
  TrendingUp, 
  DollarSign, 
  Package, 
  AlertTriangle, 
  BrainCircuit,
  Calendar,
  Loader2
} from 'lucide-react';
import { DB } from '../services/db';
import { getBusinessInsights } from '../services/geminiService';
import { Product, Sale } from '../types';

const Dashboard: React.FC = () => {
  const [insights, setInsights] = useState<string>("Analyzing your shop performance...");
  const [loadingInsights, setLoadingInsights] = useState(true);
  const [loadingData, setLoadingData] = useState(true);
  const [products, setProducts] = useState<Product[]>([]);
  const [sales, setSales] = useState<Sale[]>([]);

  useEffect(() => {
    const fetchData = async () => {
      try {
        setLoadingData(true);
        const [prodData, salesData] = await Promise.all([
          DB.getProducts(),
          DB.getSales()
        ]);
        setProducts(prodData);
        setSales(salesData);
      } catch (err) {
        console.error("Dashboard Load Error:", err);
      } finally {
        setLoadingData(false);
      }
    };
    fetchData();
  }, []);

  useEffect(() => {
    if (products.length > 0 || sales.length > 0) {
      const fetchInsights = async () => {
        setLoadingInsights(true);
        const text = await getBusinessInsights(products, sales);
        setInsights(text || "No insights available.");
        setLoadingInsights(false);
      };
      fetchInsights();
    }
  }, [products, sales]);

  const stats = useMemo(() => {
    const today = new Date().toISOString().split('T')[0];
    const todaySales = sales.filter(s => s.timestamp.startsWith(today));
    const totalSalesValue = todaySales.reduce((acc, curr) => acc + curr.totalPrice, 0);
    const totalProfitValue = todaySales.reduce((acc, curr) => acc + curr.profit, 0);
    const lowStock = products.filter(p => p.stock < 10).length;

    const last7Days = [...Array(7)].map((_, i) => {
      const d = new Date();
      d.setDate(d.getDate() - i);
      const dayString = d.toISOString().split('T')[0];
      const daySales = sales.filter(s => s.timestamp.startsWith(dayString));
      return {
        date: dayString.split('-').slice(1).join('/'),
        revenue: daySales.reduce((acc, curr) => acc + curr.totalPrice, 0),
        profit: daySales.reduce((acc, curr) => acc + curr.profit, 0)
      };
    }).reverse();

    return { totalSalesValue, totalProfitValue, lowStock, chartData: last7Days };
  }, [sales, products]);

  if (loadingData) {
    return (
      <div className="h-full flex flex-col items-center justify-center space-y-4 opacity-50">
        <Loader2 className="w-12 h-12 text-blue-500 animate-spin" />
        <p className="font-orbitron tracking-widest text-sm">SYNCING_CLOUD_DATA...</p>
      </div>
    );
  }

  const cards = [
    { label: "Today's Revenue", value: `৳${stats.totalSalesValue.toLocaleString()}`, icon: DollarSign, color: "blue" },
    { label: "Today's Profit", value: `৳${stats.totalProfitValue.toLocaleString()}`, icon: TrendingUp, color: "green" },
    { label: "Total Products", value: products.length, icon: Package, color: "purple" },
    { label: "Low Stock Items", value: stats.lowStock, icon: AlertTriangle, color: "red" },
  ];

  return (
    <div className="space-y-8 animate-in fade-in duration-700">
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <h2 className="text-2xl font-bold font-orbitron tracking-tight text-white uppercase flex items-center gap-3">
            COMMAND CENTER
            <span className="text-[10px] bg-blue-500/10 text-blue-500 px-2 py-0.5 rounded border border-blue-500/20">LIVE_LINK_ACTIVE</span>
          </h2>
          <p className="text-slate-400 text-sm mt-1">Real-time Supabase cloud monitoring active.</p>
        </div>
        <div className="flex items-center gap-2 bg-slate-900 px-4 py-2 rounded-lg border border-slate-800 text-slate-300 text-sm">
          <Calendar className="w-4 h-4" />
          {new Date().toLocaleDateString('en-US', { month: 'long', day: 'numeric', year: 'numeric' })}
        </div>
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
        {cards.map((card, i) => (
          <div key={i} className="bg-slate-900 p-6 rounded-2xl border border-slate-800 relative overflow-hidden group">
            <div className={`absolute top-0 right-0 p-4 opacity-5 group-hover:opacity-10 transition-opacity`}>
              <card.icon className="w-20 h-20" />
            </div>
            <div className={`w-12 h-12 rounded-xl bg-${card.color}-500/10 flex items-center justify-center mb-4`}>
              <card.icon className={`w-6 h-6 text-${card.color}-500`} />
            </div>
            <p className="text-slate-400 text-xs font-semibold uppercase tracking-wider">{card.label}</p>
            <h3 className="text-2xl font-bold text-slate-100 mt-1">{card.value}</h3>
          </div>
        ))}
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        <div className="lg:col-span-2 bg-slate-900 p-6 rounded-2xl border border-slate-800">
          <div className="flex items-center justify-between mb-6">
            <h3 className="text-lg font-bold">Sales & Profit Trends (7 Days)</h3>
          </div>
          <div className="h-[300px]">
            <ResponsiveContainer width="100%" height="100%">
              <AreaChart data={stats.chartData}>
                <defs>
                  <linearGradient id="colorRevenue" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor="#2563eb" stopOpacity={0.3}/>
                    <stop offset="95%" stopColor="#2563eb" stopOpacity={0}/>
                  </linearGradient>
                  <linearGradient id="colorProfit" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor="#10b981" stopOpacity={0.3}/>
                    <stop offset="95%" stopColor="#10b981" stopOpacity={0}/>
                  </linearGradient>
                </defs>
                <CartesianGrid strokeDasharray="3 3" stroke="#1e293b" vertical={false} />
                <XAxis dataKey="date" stroke="#64748b" fontSize={12} tickLine={false} axisLine={false} />
                <YAxis stroke="#64748b" fontSize={12} tickLine={false} axisLine={false} />
                <Tooltip 
                  contentStyle={{ backgroundColor: '#0f172a', border: '1px solid #1e293b', borderRadius: '8px' }}
                  itemStyle={{ fontSize: '12px' }}
                />
                <Area type="monotone" dataKey="revenue" stroke="#2563eb" fillOpacity={1} fill="url(#colorRevenue)" strokeWidth={2} />
                <Area type="monotone" dataKey="profit" stroke="#10b981" fillOpacity={1} fill="url(#colorProfit)" strokeWidth={2} />
              </AreaChart>
            </ResponsiveContainer>
          </div>
        </div>

        <div className="bg-slate-900/50 p-6 rounded-2xl border border-blue-500/20 relative overflow-hidden flex flex-col">
          <div className="absolute top-0 right-0 p-4">
            <BrainCircuit className="w-8 h-8 text-blue-500/20" />
          </div>
          <div className="flex items-center gap-2 mb-4">
            <span className="bg-blue-600 text-[10px] font-bold px-2 py-0.5 rounded text-white uppercase">AI Coach</span>
            <h3 className="text-lg font-bold text-blue-400">Business Insights</h3>
          </div>
          <div className="flex-1 overflow-y-auto pr-2">
            {loadingInsights ? (
              <div className="space-y-3">
                <div className="h-4 bg-slate-800 rounded animate-pulse w-full"></div>
                <div className="h-4 bg-slate-800 rounded animate-pulse w-5/6"></div>
                <div className="h-4 bg-slate-800 rounded animate-pulse w-4/6"></div>
              </div>
            ) : (
              <p className="text-slate-300 text-sm leading-relaxed whitespace-pre-line italic">
                "{insights}"
              </p>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};

export default Dashboard;
