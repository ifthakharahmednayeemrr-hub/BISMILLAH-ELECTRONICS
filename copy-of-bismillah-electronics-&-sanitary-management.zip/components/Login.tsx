
import React, { useState } from 'react';
import { User } from '../types';
import { Zap, Eye, EyeOff, ShieldCheck, Mail, Lock, CircuitBoard, Loader2 } from 'lucide-react';
import { DB } from '../services/db';

interface LoginProps {
  onLogin: (user: User) => void;
}

const Login: React.FC<LoginProps> = ({ onLogin }) => {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [showPassword, setShowPassword] = useState(false);
  const [isLoggingIn, setIsLoggingIn] = useState(false);
  const [error, setError] = useState('');

  const handleLogin = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsLoggingIn(true);
    setError('');

    try {
      const users = await DB.getUsers();
      const user = users.find(u => u.email === email && u.password === password);

      if (user) {
        onLogin(user);
      } else {
        setError('CLOUD_AUTH_REJECTED: Invalid Node Credentials');
      }
    } catch (err) {
      console.error(err);
      setError('CONNECTION_ERROR: Supabase Cluster Offline');
    } finally {
      setIsLoggingIn(false);
    }
  };

  return (
    <div className="min-h-screen flex items-center justify-center p-6 bg-[#020617] relative overflow-hidden font-inter text-slate-200">
      <div className="absolute inset-0 opacity-10">
        <svg className="w-full h-full" xmlns="http://www.w3.org/2000/svg"><pattern id="circuit" x="0" y="0" width="100" height="100" patternUnits="userSpaceOnUse"><path d="M0 50 L100 50 M50 0 L50 100" stroke="#1e40af" strokeWidth="0.5" fill="none" /></pattern><rect width="100%" height="100%" fill="url(#circuit)" /></svg>
      </div>

      <div className="w-full max-w-5xl grid grid-cols-1 lg:grid-cols-2 bg-slate-900/40 rounded-[2.5rem] border border-slate-800 shadow-2xl backdrop-blur-3xl relative z-10 overflow-hidden">
        <div className="hidden lg:flex flex-col justify-between p-12 bg-gradient-to-br from-blue-900/20 to-slate-950">
          <div>
            <div className="flex items-center gap-4 mb-10">
              <div className="w-12 h-12 rounded-2xl bg-blue-600 flex items-center justify-center shadow-2xl shadow-blue-600/50"><Zap className="w-8 h-8 text-white" /></div>
              <h1 className="text-2xl font-orbitron font-bold tracking-tighter">BISMILLAH ELECTRONICS</h1>
            </div>
            <h2 className="text-4xl font-bold leading-tight mb-6 uppercase tracking-tighter">Secure <span className="text-blue-500">Backend</span><br />Cloud Terminal</h2>
            <p className="text-slate-400 text-lg">Connected to Supabase High-Availability Cluster.</p>
          </div>
          <div className="flex items-center gap-4 p-4 bg-slate-950/50 rounded-2xl border border-blue-500/10">
            <ShieldCheck className="w-6 h-6 text-blue-500" />
            <div><p className="text-[10px] font-bold text-blue-400 uppercase tracking-widest">Global Auth Active</p><p className="text-[9px] text-slate-500 font-mono uppercase">Node: xbuikrolablrwzriugvb</p></div>
          </div>
        </div>

        <div className="p-12 lg:p-16">
          <h3 className="text-2xl font-bold mb-8 uppercase tracking-tighter font-orbitron">Initialize Uplink</h3>
          <form onSubmit={handleLogin} className="space-y-6">
            <div className="space-y-2">
              <label className="text-[10px] font-bold text-slate-500 uppercase">Access Identity</label>
              <div className="relative">
                <Mail className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-slate-500" />
                <input required type="email" className="w-full bg-slate-950 border border-slate-800 rounded-2xl pl-12 pr-4 py-4 focus:border-blue-500 transition-all outline-none" placeholder="node@supabase.com" value={email} onChange={e => setEmail(e.target.value)} />
              </div>
            </div>
            <div className="space-y-2">
              <label className="text-[10px] font-bold text-slate-500 uppercase">Access Token</label>
              <div className="relative">
                <Lock className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-slate-500" />
                <input required type={showPassword ? 'text' : 'password'} className="w-full bg-slate-950 border border-slate-800 rounded-2xl pl-12 pr-12 py-4 focus:border-blue-500 transition-all outline-none" placeholder="••••••••" value={password} onChange={e => setPassword(e.target.value)} />
                <button type="button" onClick={() => setShowPassword(!showPassword)} className="absolute right-4 top-1/2 -translate-y-1/2 text-slate-600 hover:text-white">{showPassword ? <EyeOff className="w-5 h-5" /> : <Eye className="w-5 h-5" />}</button>
              </div>
            </div>
            {error && <div className="p-4 bg-red-500/10 border border-red-500/20 text-red-500 text-[10px] font-bold uppercase tracking-widest">{error}</div>}
            <button disabled={isLoggingIn} className="w-full py-4 rounded-2xl bg-blue-600 hover:bg-blue-500 font-bold uppercase tracking-widest flex items-center justify-center gap-3 active:scale-[0.98] transition-all">
              {isLoggingIn ? <Loader2 className="w-6 h-6 animate-spin" /> : 'Request Cloud Handshake'}
            </button>
          </form>
          <div className="mt-8 p-4 bg-slate-800/20 rounded-xl border border-slate-800 text-[10px] text-slate-500 flex justify-between">
            <span>ADMIN: admin@bes.com</span>
            <span>STAFF: staff@bes.com</span>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Login;
