import { GoogleGenAI } from "@google/genai";
import { Product, Sale } from "../types";

// Always initialize GoogleGenAI using the process.env.API_KEY strictly as required by the SDK guidelines
const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });

export const getBusinessInsights = async (products: Product[], sales: Sale[]) => {
  try {
    const summary = {
      productCount: products.length,
      lowStock: products.filter(p => p.stock < 5).map(p => p.name),
      recentSales: sales.slice(-10).map(s => `${s.productName} qty ${s.quantity}`)
    };

    // Use ai.models.generateContent to fetch results using the specified Gemini 3 series model
    const response = await ai.models.generateContent({
      model: "gemini-3-flash-preview",
      contents: `Analyze this shop data for Bismillah Electronics: ${JSON.stringify(summary)}. 
      Provide a short professional business report focusing on: 
      1. Inventory health. 
      2. Sales trends. 
      3. Practical advice for the owner. Keep it under 150 words.`,
      config: {
        temperature: 0.7,
      }
    });

    // Directly access the text property as a string (do not call as a method)
    return response.text;
  } catch (error) {
    console.error("Gemini Error:", error);
    return "Unable to generate insights at the moment. Please check your network.";
  }
};