
import { createClient } from '@supabase/supabase-js';
import { Product, Sale, User, UserRole } from '../types';

const SUPABASE_URL = 'https://xbuikrolablrwzriugvb.supabase.co';
const SUPABASE_KEY = 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6InhidWlrcm9sYWJscnd6cml1Z3ZiIiwicm9sZSI6ImFub24iLCJpYXQiOjE3Njk1ODkwMDksImV4cCI6MjA4NTE2NTAwOX0.ot_ARf3v7EwrUNb4g6zfxzn8sqmjo_Y1XgISfumCuAM';

export const supabase = createClient(SUPABASE_URL, SUPABASE_KEY);

const STORAGE_KEYS = {
  CURRENT_USER: 'bes_current_user'
};

export const DB = {
  getProducts: async (): Promise<Product[]> => {
    const { data, error } = await supabase
      .from('products')
      .select('*')
      .order('dateAdded', { ascending: false });
    if (error) throw error;
    return data || [];
  },

  saveProduct: async (product: Product): Promise<void> => {
    const { error } = await supabase
      .from('products')
      .upsert(product);
    if (error) throw error;
  },

  deleteProduct: async (id: string): Promise<void> => {
    const { error } = await supabase
      .from('products')
      .delete()
      .eq('id', id);
    if (error) throw error;
  },

  getSales: async (): Promise<Sale[]> => {
    const { data, error } = await supabase
      .from('sales')
      .select('*')
      .order('timestamp', { ascending: false });
    if (error) throw error;
    return data || [];
  },

  addSales: async (sales: Sale[]): Promise<void> => {
    const { error } = await supabase
      .from('sales')
      .insert(sales);
    if (error) throw error;
  },

  updateStock: async (productId: string, newStock: number): Promise<void> => {
    const { error } = await supabase
      .from('products')
      .update({ stock: newStock })
      .eq('id', productId);
    if (error) throw error;
  },

  getUsers: async (): Promise<User[]> => {
    const { data, error } = await supabase
      .from('users')
      .select('*');
    if (error) throw error;
    return data || [];
  },

  getCurrentUser: (): User | null => {
    const data = localStorage.getItem(STORAGE_KEYS.CURRENT_USER);
    return data ? JSON.parse(data) : null;
  },

  setCurrentUser: (user: User | null) => {
    if (user) localStorage.setItem(STORAGE_KEYS.CURRENT_USER, JSON.stringify(user));
    else localStorage.removeItem(STORAGE_KEYS.CURRENT_USER);
  }
};
