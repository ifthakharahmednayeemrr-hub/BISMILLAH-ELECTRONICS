import React, { useState, useEffect } from 'react';
import Login from './components/Login';
import Layout from './components/Layout';
import Dashboard from './components/Dashboard';
import Inventory from './components/Inventory';
import POS from './components/POS';
import { DB } from './services/db';
import { User, UserRole } from './types';

const App: React.FC = () => {
  const [user, setUser] = useState<User | null>(null);
  const [activeTab, setActiveTab] = useState('dashboard');
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    // Fix: Removed DB.init() as it is not defined in the DB service object
    const currentUser = DB.getCurrentUser();
    if (currentUser) {
      setUser(currentUser);
      setActiveTab(currentUser.role === UserRole.ADMIN ? 'dashboard' : 'pos');
    }
    setIsLoading(false);
  }, []);

  const handleLogin = (authenticatedUser: User) => {
    setUser(authenticatedUser);
    DB.setCurrentUser(authenticatedUser);
    setActiveTab(authenticatedUser.role === UserRole.ADMIN ? 'dashboard' : 'pos');
  };

  const handleLogout = () => {
    setUser(null);
    DB.setCurrentUser(null);
    setActiveTab('dashboard');
  };

  if (isLoading) {
    return (
      <div className="min-h-screen bg-slate-950 flex items-center justify-center">
        <div className="w-12 h-12 border-4 border-blue-600 border-t-transparent rounded-full animate-spin shadow-[0_0_15px_rgba(37,99,235,0.5)]"></div>
      </div>
    );
  }

  if (!user) {
    return <Login onLogin={handleLogin} />;
  }

  return (
    <Layout 
      activeTab={activeTab} 
      setActiveTab={setActiveTab} 
      onLogout={handleLogout}
    >
      {activeTab === 'dashboard' && <Dashboard />}
      {activeTab === 'inventory' && <Inventory />}
      {activeTab === 'pos' && <POS />}
      {activeTab === 'reports' && (
        <div className="flex flex-col items-center justify-center py-20 opacity-50">
          <h2 className="text-2xl font-orbitron mb-4">REPORTS MODULE</h2>
          <p>Detailed PDF & Excel reports coming soon in v2.1</p>
        </div>
      )}
      {activeTab === 'employees' && (
        <div className="flex flex-col items-center justify-center py-20 opacity-50">
          <h2 className="text-2xl font-orbitron mb-4">EMPLOYEE MANAGEMENT</h2>
          <p>HR management console coming soon in v2.1</p>
        </div>
      )}
    </Layout>
  );
};

export default App;