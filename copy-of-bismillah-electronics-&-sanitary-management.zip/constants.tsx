
import React from 'react';

export const CIRCUIT_PATTERN = (
  <svg className="absolute inset-0 w-full h-full opacity-10 pointer-events-none" xmlns="http://www.w3.org/2000/svg">
    <defs>
      <pattern id="circuit" x="0" y="0" width="100" height="100" patternUnits="userSpaceOnUse">
        <path d="M10 10 H90 V90 H10 Z" fill="none" stroke="currentColor" strokeWidth="0.5" />
        <circle cx="10" cy="10" r="2" fill="currentColor" />
        <circle cx="90" cy="90" r="2" fill="currentColor" />
        <path d="M50 10 V50 H90" fill="none" stroke="currentColor" strokeWidth="0.5" />
        <path d="M10 50 H50 V90" fill="none" stroke="currentColor" strokeWidth="0.5" />
      </pattern>
    </defs>
    <rect width="100%" height="100%" fill="url(#circuit)" />
  </svg>
);

export const CATEGORIES = [
  "LED & Lighting",
  "Circuit Breakers",
  "Sanitary Pipes",
  "Taps & Faucets",
  "Cables & Wires",
  "Switches & Sockets",
  "Water Pumps",
  "Fans & Coolers"
];
