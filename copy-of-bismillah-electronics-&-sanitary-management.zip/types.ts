
export enum UserRole {
  ADMIN = 'ADMIN',
  EMPLOYEE = 'EMPLOYEE'
}

export interface User {
  id: string;
  name: string;
  email: string;
  role: UserRole;
  password?: string;
  lastLogin?: string;
}

export interface Product {
  id: string;
  name: string;
  code: string;
  category: string;
  purchasePrice: number;
  sellingPrice: number;
  stock: number;
  dateAdded: string;
  supplier?: string;
}

export interface Sale {
  id: string;
  productCode: string;
  productName: string;
  quantity: number;
  unitPrice: number;
  totalPrice: number;
  profit: number;
  timestamp: string;
  soldBy: string; // User ID
}

export interface DashboardStats {
  todaySales: number;
  todayProfit: number;
  totalProducts: number;
  lowStockCount: number;
  monthlyRevenue: { month: string; amount: number }[];
  monthlyProfit: { month: string; amount: number }[];
}
